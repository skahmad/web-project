<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T17:56:12+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: web.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:48:50+05:30
# @Copyright: moonweb@2018




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// for Admin
Route::group([
    'prefix'=>'admin',
    'as'=>'admin.'
], function() {
    Route::get("/","Admin\HomeController@index")->name("home");
    Route::get("logout", "Admin\LoginController@logout")->name("logout");
    Route::view("login",'admin.login')->name('login');
    Route::view('register', 'admin.register')->name('register');

    Route::post("login","Admin\LoginController@login")->name("login");
    Route::post("register","Admin\RegisterController@register")->name("register");
});

// for Employee

Route::group([
    'prefix'=>'employee',
    'as'=>'employee.'
], function() {
    Route::get("/","Employee\HomeController@index")->name("home");
    Route::get("logout", "Employee\LoginController@logout")->name("logout");

    Route::view("login",'employee.login')->name('login');
    Route::view('register', 'employee.register')->name('register');

    Route::post("login","Employee\LoginController@login")->name("login");
    Route::post("register","Employee\RegisterController@register")->name("register");
});


// for Manager

Route::group([
    'prefix'=>'manager',
    'as'=>'manager.'
], function() {
    Route::get("/","Manager\HomeController@index")->name("home");
    Route::get("logout", "Manager\LoginController@logout")->name("logout");

    Route::view("login",'manager.login')->name('login');
    Route::view('register', 'manager.register')->name('register');

    Route::post("login","Manager\LoginController@login")->name("login");
    Route::post("register","Manager\RegisterController@register")->name("register");
});
