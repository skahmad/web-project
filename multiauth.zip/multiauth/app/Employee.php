<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:37:00+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: Employee.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:27:57+05:30
# @Copyright: moonweb@2018




namespace App;

use Illuminate\Auth\MustVerifyEmail;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Contracts\Auth\MustVerifyEmail as MustVerifyEmailContract;

class Employee extends Authenticatable {
    use Notifiable;

    protected $guard = 'employee';  // if comment it, not effect in login or logout
    protected $fillable = [
        'email', 'password',
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];
}
