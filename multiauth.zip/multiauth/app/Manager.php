<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:36:20+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: Manager.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:27:48+05:30
# @Copyright: moonweb@2018




namespace App;

use Illuminate\Auth\MustVerifyEmail;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Contracts\Auth\MustVerifyEmail as MustVerifyEmailContract;

class Manager extends Authenticatable{
    use Notifiable;
    protected $guard = 'manager';  // if comment it, not effect in login or logout
    protected $fillable = [
        'email', 'password',
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];

}
