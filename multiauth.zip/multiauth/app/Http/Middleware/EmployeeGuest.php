<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:42:37+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: EmployeeGuest.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T23:14:13+05:30
# @Copyright: moonweb@2018




namespace App\Http\Middleware;

use Closure;
use Auth;

class EmployeeGuest
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        // dd($request);
        if(! \App\Employee::where("email",$request->email)->exists() )
            return back()->withError("Creadential Not Match");
        if(Auth::guard("employee")->check()){
            return redirect()->route("employee");
        }
        return $next($request);
    }
}
