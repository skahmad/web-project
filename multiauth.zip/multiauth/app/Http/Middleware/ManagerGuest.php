<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:42:24+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: ManagerGuest.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T23:07:32+05:30
# @Copyright: moonweb@2018




namespace App\Http\Middleware;

use Closure;
use Auth;

class ManagerGuest
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        if(! \App\Manager::where('email', '=', $request->email)->exists()){
            return back()->withError("Creadential not match");
        }
        if(Auth::guard("manager")->check()){
            return redirect()->route("manager");
        }
        return $next($request);
    }
}
