<?php

namespace App\Http\Middleware;

use Closure;

class helpmiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $opt)
    {
        print "Option : ".$opt;
        return $next($request);
    }
}
