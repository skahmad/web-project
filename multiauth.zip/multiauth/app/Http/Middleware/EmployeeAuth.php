<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:42:30+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: EmployeeAuth.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T23:12:21+05:30
# @Copyright: moonweb@2018




namespace App\Http\Middleware;

use Closure;
use Auth;
class EmployeeAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        // dd("Employee Auth");
        if(! Auth::guard("employee")->check())
            return redirect()->route("employee.login");
        return $next($request);
    }
}
