<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:41:55+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: AdminAuth.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:47:13+05:30
# @Copyright: moonweb@2018




namespace App\Http\Middleware;

use Closure;
use Auth;

class AdminAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        // dd("Admin Auth");
        if(!Auth::guard("admin")->check()){
            return redirect()->route("admin.login");
        }
        return $next($request);
    }
}
