<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:34:57+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: HomeController.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:30:31+05:30
# @Copyright: moonweb@2018




namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeController extends Controller {
    public function __construct() {
        $this->middleware("m.auth");
    }
    public function index() {
        return view('manager.home');
    }
}
