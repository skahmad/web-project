<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:35:35+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: LoginController.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:52:14+05:30
# @Copyright: moonweb@2018




namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers; // must be use this namesapce
use Auth;

class LoginController extends Controller {
    use AuthenticatesUsers;
    protected $redirectTo = '/employee';

    public function __construct(Request $req) {
        // dd("Employee login constructor");
        // dd($req);
        $this->middleware("e.guest")->except("logout");
    }

    // required to override guard method
    // this mehtod must be overridden, otherwise problem in login
    protected function guard(){
        return Auth::guard('employee');
    }

    // custom logout method
    public function logout() {
        // auth('admin')->logout(); // both are same
        $this->guard()->logout();
        return redirect()->route("employee.login");
    }

}
