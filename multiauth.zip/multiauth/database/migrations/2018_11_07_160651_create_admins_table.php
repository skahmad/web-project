<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:36:51+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: 2018_11_07_160651_create_admins_table.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:22:27+05:30
# @Copyright: moonweb@2018




use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdminsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admins', function (Blueprint $table) {
            $table->increments('id');
            $table->string("name",62);
            $table->string("phone");
            $table->string("email",62)->unique();
            $table->string("password");
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admins');
    }
}
