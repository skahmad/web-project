<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T20:36:35+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: register.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T20:44:47+05:30
# @Copyright: moonweb@2018
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Manager Register</title>
        @include("link")
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-xs-6">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Manager Registration</h2>
                        </header>
                        <div class="content-body">
                            <div class="row">

                                <form action="#" method="post">
                                    <div class="col-md-12">
			                            <div class="form-group">
                                            <label class="form-label">Name</label>
                                            <span class="desc"></span>
                                            <div class="controls">
                                                <input type="text" value="" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Email</label>
                                            <span class="desc"></span>
                                            <div class="controls">
                                                <input type="email" value="" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                             <label class="form-label">Phone</label>
                                             <span class="desc"></span>
                                             <div class="controls">
                                                 <input type="number" value="" class="form-control">
                                             </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Password</label>
                                            <span class="desc"></span>
                                            <div class="controls">
                                                <input type="password" value="" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Confirm Password</label>
                                            <span class="desc"></span>
                                            <div class="controls">
                                                <input type="password" value="" class="form-control">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-9 col-md-8 padding-bottom-30">
                                        	<div class="text-left">
                                            <button type="submit" class="btn btn-primary">Register</button>
                                            <button type="button" class="btn btn-info">Clear</button>
                                            <a type="button" class="btn" href="{{ route('manager.login') }}" >Login</a>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </body>
</html>
