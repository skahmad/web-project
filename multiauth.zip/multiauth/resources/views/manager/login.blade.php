<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T20:29:22+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: login.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T23:06:59+05:30
# @Copyright: moonweb@2018
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Manager Login</title>
        @include('link')
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-xs-6">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Manager Login</h2>
                        </header>
                        <div class="content-body">
                            <div class="row">

                                <form action="{{ route('manager.login') }}" method="post">@csrf
                                    <div class="col-md-12 col-sm-9">
                        			    <div class="form-group">
                                            <label class="form-label">Email</label>
                                            <span class="desc">
                                                @if(session()->get('error'))
                                                    {{ session()->get("error") }}
                                                @endif
                                            </span>
                                            <div class="controls">
                                                <input type="email" placeholder="Email" class="form-control" name="email">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Password</label>
                                            <div class="controls">
                                                <input type="password" placeholder="Password" class="form-control" name="password">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-9 col-md-8 padding-bottom-30">
                            	       <div class="text-left">
                                            <button type="submit" class="btn btn-primary">Login</button>
                                            <a type="button" class="btn" href="{{ route('manager.register') }}">Register</a>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </body>

    @include('script')
</html>
