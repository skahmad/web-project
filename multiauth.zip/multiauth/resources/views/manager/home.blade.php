<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T20:45:25+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: home.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:49:55+05:30
# @Copyright: moonweb@2018
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Manager Dashboard</title>
        @include("link")
    </head>
    <body>
        <div class="container">
            <div class="row">
                <section class="wrapper main-wrapper row" style="">

    <div class="col-xs-12">
        <div class="page-title">

            <div class="pull-left">
                <h1 class="title">Manager Dashboard</h1>
            </div>
            <div class="actions panel_actions pull-right">
            	<a class="btn btn-danger" href="{{ route("manager.logout") }}">Logout</a>
            </div>

        </div>
    </div>
    <div class="clearfix"></div>


<div class="col-lg-12">
    <section class="box ">
            <header class="panel_header">
                <h2 class="title pull-left">Trending Albums</h2>
                <div class="actions panel_actions pull-right">
                	<a class="box_toggle fa fa-chevron-down"></a>
                    <a class="box_setting fa fa-cog" data-toggle="modal" href="#section-settings"></a>
                    <a class="box_close fa fa-times"></a>
                </div>
            </header>
            <div class="content-body">
    <div class="row"><div class="col-md-12">



                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-1.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Modern Roc..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Mellisa</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-2.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Hard Metal..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Jude</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-3.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Love Songs..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Jack</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-4.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Instrument..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Jackson</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-5.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Made for y..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Law Tiger</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-6.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Kiss the s..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Misterious</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-7.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            In the Dep..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Blank</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-8.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Volcano..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Martini</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-9.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Juicy touc..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Jingle</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-1.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Modern Roc..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Mellisa</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-2.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Hard Metal..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Jude</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-3.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Love Songs..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Jack</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-4.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Instrument..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Jackson</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-5.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Made for y..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Law Tiger</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-6.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Kiss the s..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Misterious</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-7.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            In the Dep..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Blank</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-8.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Volcano..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Martini</a></span>
                                                    </div>

                    </div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">

                                    <div class="thumb">
                                    <img class="img-responsive" src="data/albums/album-9.jpg">
                                    <div class="overlay"><a href="mus-album-view.html"><i class="fa fa-play"></i></a></div>
                                    </div>

                                                <div class="team-info ">
                            <h4>


                            <a href="mus-album-view.html">
                            Juicy touc..</a>


                            </h4>


                                                        <span><a href="mus-artist-profile.html">Jingle</a></span>
                                                    </div>

                    </div>
                </div>
            </div></div>

    </div>
        </section></div>


<div class="col-lg-12">
    <section class="box ">
            <header class="panel_header">
                <h2 class="title pull-left">Trending Songs</h2>
                <div class="actions panel_actions pull-right">
                	<a class="box_toggle fa fa-chevron-down"></a>
                    <a class="box_setting fa fa-cog" data-toggle="modal" href="#section-settings"></a>
                    <a class="box_close fa fa-times"></a>
                </div>
            </header>
            <div class="content-body">
    <div class="row"><div class="col-md-12">



                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-1.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">ligula pel..</a></h4>
                            <span>ahayes0</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-2.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">at ipsum a..</a></h4>
                            <span>dross1</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-3.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">amet eleif..</a></h4>
                            <span>bphillips2</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-4.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">nulla moll..</a></h4>
                            <span>sramos3</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-5.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">nulla temp..</a></h4>
                            <span>sdean4</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-6.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">felis ut a..</a></h4>
                            <span>amyers5</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-7.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">vel enim s..</a></h4>
                            <span>gaustin6</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-8.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">nibh quisq..</a></h4>
                            <span>jharper7</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-9.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">nulla dapi..</a></h4>
                            <span>amartinez8</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-10.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">etiam vel ..</a></h4>
                            <span>hallen9</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-11.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">duis ac ni..</a></h4>
                            <span>pcarrolla</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-12.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">montes nas..</a></h4>
                            <span>mharrisb</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-13.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">eros suspe..</a></h4>
                            <span>rwoodsc</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-14.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">nisl duis ..</a></h4>
                            <span>spattersond</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-15.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">vulputate ..</a></h4>
                            <span>afishere</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-16.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">fusce cong..</a></h4>
                            <span>cwilsonf</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-17.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">augue vest..</a></h4>
                            <span>rholmesg</span>
                        </div>

                        <p>
                    </p></div>
                </div>


                <div class="col-lg-2 col-sm-4 col-xs-6 music_genre">
                    <div class="team-member ">
                        <div class="team-img thumb ">
                            <img class="img-responsive" src="data/songs/song-18.jpg" alt="">
                            <div class="overlay">
                                <a href="mus-song-view.html"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                        <div class="team-info ">
                            <h4><a href="mus-genre-profile.html">magna ac c..</a></h4>
                            <span>wfranklinh</span>
                        </div>

                        <p>
                    </p></div>
                </div>




    </div></div>

    </div>
        </section></div>

<div class="col-lg-6">
    <section class="box ">
            <header class="panel_header">
                <h2 class="title pull-left">New Registrations</h2>
                <div class="actions panel_actions pull-right">
                	<a class="box_toggle fa fa-chevron-down"></a>
                    <a class="box_setting fa fa-cog" data-toggle="modal" href="#section-settings"></a>
                    <a class="box_close fa fa-times"></a>
                </div>
            </header>
            <div class="content-body">
<table class="table table-hover">
                            <thead>
                                <tr>
                                    <th style="width:60%">Name</th>
                                    <th style="width:30%">Profile Progress</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>

                                    <td>Harry P.</td>
                                    <td><span class="playlist_song2"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>
                                <tr>

                                    <td>Will Mark</td>
                                    <td><span class="playlist_song3"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>
                                <tr>

                                    <td>Jason D.</td>
                                    <td><span class="playlist_song4"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>

                                <tr>

                                    <td>Nik P.</td>
                                    <td><span class="playlist_song6"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>
                                <tr>

                                    <td>Kate Wilson</td>
                                    <td><span class="playlist_song7"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>
                            </tbody>
                        </table>
    </div>
        </section></div>

<div class="col-lg-6">
    <section class="box ">
            <header class="panel_header">
                <h2 class="title pull-left">Trending Playlist</h2>
                <div class="actions panel_actions pull-right">
                	<a class="box_toggle fa fa-chevron-down"></a>
                    <a class="box_setting fa fa-cog" data-toggle="modal" href="#section-settings"></a>
                    <a class="box_close fa fa-times"></a>
                </div>
            </header>
            <div class="content-body">
<table class="table table-hover">
                            <thead>
                                <tr>
                                    <th style="width:60%">Name</th>
                                    <th style="width:30%">Trending</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>

                                    <td>Harry P.</td>
                                    <td><span class="playlist_song2"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>
                                <tr>

                                    <td>Will Mark</td>
                                    <td><span class="playlist_song3"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>
                                <tr>

                                    <td>Jason D.</td>
                                    <td><span class="playlist_song4"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>

                                <tr>

                                    <td>Nik P.</td>
                                    <td><span class="playlist_song6"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>
                                <tr>

                                    <td>Kate Wilson</td>
                                    <td><span class="playlist_song7"><canvas width="49" height="20" style="display: inline-block; width: 49px; height: 20px; vertical-align: top;"></canvas></span></td>
                                </tr>
                            </tbody>
                        </table>
    </div>
        </section></div>



    </section>
            </div>
        </div>
    </body>
</html>
