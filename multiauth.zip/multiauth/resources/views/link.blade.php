<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T18:28:28+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: link.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T18:38:38+05:30
# @Copyright: moonweb@2018
?>

<link rel="stylesheet" href="{{ asset('css/style.css') }}">
<link rel="stylesheet" href="{{ asset('bootstrap/css/bootstrap.min.css') }}">
