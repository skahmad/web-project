<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:11:02+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: home.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:50:03+05:30
# @Copyright: moonweb@2018
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Employee Dashboard</title>
        @include("link")
    </head>
    <body>
        <div class="container">
            <div class="row">

                <div class="col-xs-12">
                    <div class="page-title">
                        <div class="pull-left">
                            <h1 class="title">Employee Dashboard</h1>
                        </div>
                        <div class="actions panel_actions pull-right">
                        	<a class="btn btn-danger" href="{{ route("employee.logout") }}">Logout</a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-12">
                    <section class="box-nobox">
                        <div class="content-body">
                            <div class="row">
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <div class="r4_counter db_box">
                                        <i class="pull-left fa fa-thumbs-up icon-md icon-rounded icon-primary"></i>
                                        <div class="stats">
                                            <h4><strong>450K</strong></h4>
                                            <span>Blog Page Views</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <div class="r4_counter db_box">
                                        <i class="pull-left fa fa-user icon-md icon-rounded icon-accent"></i>
                                        <div class="stats">
                                            <h4><strong>6243</strong></h4>
                                            <span>New Visitors</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <div class="r4_counter db_box">
                                        <i class="pull-left fa fa-database icon-md icon-rounded icon-purple"></i>
                                        <div class="stats">
                                            <h4><strong>99.9%</strong></h4>
                                            <span>Server Up</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <div class="r4_counter db_box">
                                        <i class="pull-left fa fa-users icon-md icon-rounded icon-warning"></i>
                                        <div class="stats">
                                            <h4><strong>1433</strong></h4>
                                            <span>New Users</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </body>

</html>
