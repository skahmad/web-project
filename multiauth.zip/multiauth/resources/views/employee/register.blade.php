<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:10:54+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: register.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T21:27:40+05:30
# @Copyright: moonweb@2018
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Employee Register</title>
        @include("link")
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <section class="box ">
                        <header class="panel_header">
                                <h2 class="title pull-left">Employee Login</h2>
                            </header>
                        <div class="content-body">
                                <div class="row">
                                    <div class="col-md-12">

                                        <form>
                                            <div class="class="form-inline"">
                                                <div class="form-group">
                                                    <label class="sr-only" for="exampleInputEmail3">Name</label>
                                                    <input type="text" name="name" class="form-control" id="exampleInputEmail3" placeholder="Name">
                                                </div>
                                                <div class="form-group">
                                                    <label class="sr-only" for="exampleInputPassword3">Email</label>
                                                    <input type="email" name="email" class="form-control" id="exampleInputPassword3" placeholder="Email">
                                                </div>
                                            </div>
                                            <div class="class="form-inline"">
                                                <div class="form-group">
                                                    <label class="sr-only" for="exampleInputEmail3">Phone</label>
                                                    <input type="number" name="phone" class="form-control" id="exampleInputEmail3" placeholder="Phone">
                                                </div>
                                                <div class="form-group">
                                                    <label class="sr-only" for="exampleInputPassword3">Password</label>
                                                    <input type="password" name="password" class="form-control" id="exampleInputPassword3" placeholder="Password">
                                                </div>
                                            </div>
                                            <div class="form-inline">
                                                <button type="submit" class="btn btn-primary" href="{{ route('employee.register') }}">Register</button>
                                                <a type="button" class="btn pull-right" href="{{ route('employee.login') }}">Sign in</a>
                                            </div>

                                        </form>

                                    </div>
                                </div>

                            </div>
                    </section>
                </div>
            </div>
        </div>
    </body>

</html>
