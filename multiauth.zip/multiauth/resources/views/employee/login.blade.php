<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:10:45+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: login.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T23:10:23+05:30
# @Copyright: moonweb@2018
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Employee Login</title>
        @include("link")
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <section class="box ">
                        <header class="panel_header">
                                <h2 class="title pull-left">Employee Login</h2>
                            </header>
                            <div class="content-body">
                                <div class="row">
                                    <div class="col-md-12">

                                        <!-- <form class="form-inline" mathod="post" action="{{ route('employee.login') }}">@csrf
                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputEmail3">Email address</label>
                                                <input type="email" name="email" class="form-control" id="exampleInputEmail3" placeholder="Enter email">
                                            </div>
                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputPassword3">Password</label>
                                                <input type="password" name="password" class="form-control" id="exampleInputPassword3" placeholder="Password">
                                            </div>
                                            <button type="submit" class="btn btn-primary">Login</button>
                                             <a type="button" class="btn pull-right" href="{{ route('employee.register') }}">Register</a>
                                        </form> -->

                                        <form class="" action="{{ route('employee.login') }}" method="post">@csrf
                                            <input type="email" name="email" value="">
                                            @if(session()->get('error'))
                                                <p style="color: red">{{session()->get("error")}}</p>
                                            @endif
                                            <input type="password" name="password" value="">
                                            <input type="submit" name="" value="Login">
                                        </form>

                                    </div>
                                </div>

                            </div>
                    </section>
                </div>
            </div>
        </div>
    </body>

</html>
