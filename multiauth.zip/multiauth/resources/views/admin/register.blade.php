<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T20:52:27+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: register.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T21:06:14+05:30
# @Copyright: moonweb@2018
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Admin Registration</title>
        @include('link')
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Admin Registration</h2>
                        </header>
                        <div class="content-body">
                            <div class="row">
                                <div class="col-md-12">

                                    <form role="form">
                                        <div class="form-group">
                                            <label class="form-label" for="email-1">Name</label>
                                            <input type="email" class="form-control" id="email-1" placeholder="Enter your Name" name="name">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="email-1">Phone</label>
                                            <input type="email" class="form-control" id="email-1" placeholder="Enter your Phone" name="phone">
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="email-1">Email address:</label>
                                            <input name="email" type="email" class="form-control" id="email-1" placeholder="Enter your email…">
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="password-1">Password:</label>
                                            <input name="password" type="password" class="form-control" id="password-1" placeholder="Enter your password">
                                        </div>

                                        <div class="form-group">
                                            <button type="button" class="btn btn-purple">Register</button>
                                            <a type="button" class="btn pull-right" href="{{ route('admin.login') }}">Sign in now</a>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </body>
</html>
