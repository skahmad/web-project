<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T21:06:38+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: home.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T22:46:26+05:30
# @Copyright: moonweb@2018
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Admin Home</title>
        @include("link")
    </head>
    <body>
        <div class="container">
            <div class="row">

                <div class="col-xs-12">
    <section class="box ">
            <header class="panel_header">
                <h2 class="title pull-left">Admin Dashboard</h2>
                <div class="actions panel_actions pull-right">
                	<a class="btn btn-danger" href="{{ route("admin.logout") }}">Logout</a>
                </div>
            </header>
            <div class="content-body">    <div class="row">

        <div class="col-md-12"><h4>Default (Colored Tiles)</h4><br></div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter bg-primary">
                <div class="content">
                    <i class="fa fa-thumbs-up icon-lg"></i>
                    <h2 class="number_counter start_timer counted" data-speed="3000" data-from="1001" data-to="3504">3504</h2>
                                        <div class="clearfix"></div>
                    <span>People liked it !</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter bg-purple">
                <div class="content">
                    <i class="fa fa-heart icon-lg"></i>
                    <h2 class="number_counter start_timer counted" data-speed="3000" data-from="1001" data-to="4504">4504</h2>
                                        <div class="clearfix"></div>
                    <span>Loved your post !</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter bg-accent">
                <div class="content">
                    <i class="fa fa-user icon-lg"></i>
                    <h2 class="number_counter start_timer counted" data-speed="3000" data-from="1001" data-to="3304">3304</h2>
                                        <div class="clearfix"></div>
                    <span>New Users</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter bg-warning">
                <div class="content">
                    <i class="fa fa-share icon-lg"></i>
                    <h2 class="number_counter start_timer counted" data-speed="3000" data-from="1001" data-to="7504">7504</h2>
                                        <div class="clearfix"></div>
                    <span>Shared this post</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter bg-info">
                <div class="content">
                    <i class="fa fa-rocket icon-lg"></i>
                    <h2 class="number_counter start_timer counted" data-speed="3000" data-from="11" data-to="87">87</h2>
                    <h2>MB</h2>                     <div class="clearfix"></div>
                    <span>Server Load</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter bg-success">
                <div class="content">
                    <i class="fa fa-dashboard icon-lg"></i>
                    <h2 class="number_counter start_timer counted" data-speed="3000" data-from="100" data-to="1624">1624</h2>
                                        <div class="clearfix"></div>
                    <span>New Sites!</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter bg-danger">
                <div class="content">
                    <i class="fa fa-thumbs-down icon-lg"></i>
                    <h2 class="number_counter start_timer counted" data-speed="3000" data-from="0" data-to="224">224</h2>
                                        <div class="clearfix"></div>
                    <span>People disliked it</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter bg-secondary">
                <div class="content">
                    <i class="fa fa-bookmark icon-lg"></i>
                    <h2 class="number_counter start_timer counted" data-speed="3000" data-from="1001" data-to="9824">9824</h2>
                                        <div class="clearfix"></div>
                    <span>Pages Bookmarked!</span>
                </div>
            </div>

            </div>

        <div class="clearfix spacer20"></div>


        <div class="col-md-12"><h4>Inverted Style</h4><br></div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter inverted text-primary">
                <div class="content">
                    <i class="fa fa-thumbs-up icon-lg"></i>
                    <h2 class="number_counter" data-speed="3000" data-from="1001" data-to="3504">1001</h2>
                                        <div class="clearfix"></div>
                    <span>People liked it !</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter inverted text-purple">
                <div class="content">
                    <i class="fa fa-heart icon-lg"></i>
                    <h2 class="number_counter" data-speed="3000" data-from="1001" data-to="4504">1001</h2>
                                        <div class="clearfix"></div>
                    <span>Loved your post !</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter inverted text-accent">
                <div class="content">
                    <i class="fa fa-user icon-lg"></i>
                    <h2 class="number_counter" data-speed="3000" data-from="1001" data-to="3304">1001</h2>
                                        <div class="clearfix"></div>
                    <span>New Users</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter inverted text-warning">
                <div class="content">
                    <i class="fa fa-share icon-lg"></i>
                    <h2 class="number_counter" data-speed="3000" data-from="1001" data-to="7504">1001</h2>
                                        <div class="clearfix"></div>
                    <span>Shared this post</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter inverted text-info">
                <div class="content">
                    <i class="fa fa-rocket icon-lg"></i>
                    <h2 class="number_counter" data-speed="3000" data-from="11" data-to="87">11</h2>
                    <h2>MB</h2>                     <div class="clearfix"></div>
                    <span>Server Load</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter inverted text-success">
                <div class="content">
                    <i class="fa fa-dashboard icon-lg"></i>
                    <h2 class="number_counter" data-speed="3000" data-from="100" data-to="1624">100</h2>
                                        <div class="clearfix"></div>
                    <span>New Sites!</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter inverted text-danger">
                <div class="content">
                    <i class="fa fa-thumbs-down icon-lg"></i>
                    <h2 class="number_counter" data-speed="3000" data-from="0" data-to="224">0</h2>
                                        <div class="clearfix"></div>
                    <span>People disliked it</span>
                </div>
            </div>

            </div>

        <div class="col-xs-12 col-sm-6 col-lg-4">
                        <div class="tile-counter inverted text-secondary">
                <div class="content">
                    <i class="fa fa-bookmark icon-lg"></i>
                    <h2 class="number_counter" data-speed="3000" data-from="1001" data-to="9824">1001</h2>
                                        <div class="clearfix"></div>
                    <span>Pages Bookmarked!</span>
                </div>
            </div>

            </div>


    </div>
    </div>
        </section></div>

            </div>
        </div>
    </body>

</html>
