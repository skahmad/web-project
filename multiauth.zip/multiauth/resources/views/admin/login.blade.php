<?php
# @Author: Sk Ahmad Hossain <light>
# @Date:   2018-11-07T18:28:17+05:30
# @Email:  ahmad.sk98@gmail.com
# @Project: MoonWEB
# @Filename: login.blade.php
# @Last modified by:   light
# @Last modified time: 2018-11-07T21:53:38+05:30
# @Copyright: moonweb@2018
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Admin Login</title>
        @include("link")
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <section class="box">
                        <header class="panel_header">
                            <h2 class="title pull-left">Admin Login</h2>
                        </header>
                        <div class="content-body">
                            <div class="row">

                                <form method="post" action="{{ route('admin.login') }}">@csrf
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label
                                            class="form-label"
                                            for="field-1">Email
                                            </label>
                                            <div class="controls">
                                                <input
                                                type="email"
                                                class="form-control"
                                                id="field-1"
                                                name="email">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label
                                            class="form-label"
                                            for="field-1">Password
                                            </label>
                                            <div class="controls">
                                                <input
                                                type="password"
                                                class="form-control"
                                                id="field-1"
                                                name="password">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary">Login</button>
                                            <a type="button" class="btn" href="{{ route('admin.register') }}">Register</a>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </body>
    @include('script')
</html>
